const { src,dest,watch,series,parallel } = require('gulp');
const sass = require('gulp-dart-sass');
const autoprefixer = require('gulp-autoprefixer');
const babel = require('gulp-babel');
const rename = require('gulp-rename');
const terser = require('gulp-terser');
const webpack = require('webpack-stream');
const sourcemaps = require('gulp-sourcemaps');
const del = require('del');
const mode = require('gulp-mode')();
const browserSync = require('browser-sync').create();
const plumber = require('gulp-plumber'); //エラー時の強制終了を防止
const notify = require('gulp-notify'); //エラー発生時にデスクトップ通知する
const sassGlob = require('gulp-sass-glob'); //@importの記述を簡潔にする
const imagemin = require('gulp-imagemin');//定番の画像圧縮のパッケージ
const imageminPngquant = require("imagemin-pngquant");
const imageminMozjpeg = require("imagemin-mozjpeg");
const imageminOption = [
    imageminPngquant({ quality: [.7, .85],speed: 1 }),
    imageminMozjpeg({ quality: 85 }),
    imagemin.gifsicle({
        interlaced: false,
        optimizationLevel: 1,
        colors: 256
    }),
    imagemin.mozjpeg(),
    imagemin.optipng(),
    imagemin.svgo()
  ];
const changed = require('gulp-changed');//変更があったファイルだけを移動させたりなどの処理を行うパッケージ
const postcss = require('gulp-postcss');
const cssDeclarationSorter = require('css-declaration-sorter');//CSSのプロパティの順番を良い感じに並び替えてくれるプラグイン
const cssnano = require("cssnano");//postcssのミニファイ化プラグイン
const mqpacker = require("css-mqpacker");//postcssの同じメディアクエリーをまとめてくれるプラグイン
const cssPlugin = [
    cssDeclarationSorter({
      order: 'smacss'
    }),
    mqpacker()
  ];

//clean tasks
const clean = () =>{
    return del(['output']);
}
const cleanImages = () =>{
    return del(['output/assets/images'])
}
const cleanfonts = () =>{
    return del(['output/assets/fonts'])
}

//create css task
const css = () =>{
    return src('workspace/assets/scss/index.scss')
    .pipe( plumber({ errorHandler: notify.onError("Error: <%= error.message %>") }) )
    .pipe(mode.development(sourcemaps.init()))
    .pipe(sassGlob())
    .pipe(sass().on('error',sass.logError))
    .pipe(autoprefixer())
    .pipe(postcss(cssPlugin))
    .pipe(mode.production(postcss([cssnano({ autoprefixer: false })])))
    .pipe(rename('app.min.css'))
    .pipe(mode.development(sourcemaps.write('.')))
    .pipe(dest('output/assets/css'))
    .pipe(mode.development(browserSync.stream()));
}

//js task
const js = () =>{
    return src('workspace/**/*.js')
    .pipe( plumber({ errorHandler: notify.onError("Error: <%= error.message %>") }) )
    .pipe(babel({
        presets:['@babel/env']
    }))
    .pipe(webpack({
        mode:'development',
        devtool:'#inline-source-map'
    }))
    .pipe(mode.development(sourcemaps.init({loadMaps:true})))
    .pipe(rename('main.min.js'))
    .pipe(mode.production(terser({output:{comments:false}})))
    .pipe(mode.development(sourcemaps.write('.')))
    .pipe(dest('output/assets/js'))
    .pipe(mode.development(browserSync.stream()))
}

//copy tasks
const copyImages = ()=>{
    return src('workspace/assets/images/**/*.{jpg,jpeg,png,gif,svg}')
    .pipe( imagemin( imageminOption ) )
    .pipe(dest('output/assets/images'));
}

const copyfonts = () =>{
    return src('workspace/assets/fonts/**/*.{svg,eot,ttf,woff,woff2}')
    .pipe(dest('output/assets/fonts'));
}

const copyHtml = () =>{
    return src('workspace/*.html')
    .pipe(dest('output'));
}

//watch task
const watchForChanges = () =>{
    browserSync.init({
        server: {
            baseDir: './output',
            index: 'index.html',
        },
    });

    watch('workspace/assets/scss/**/*.scss',css);
    watch('workspace/**/*.js',js);
    watch('**/*.html').on('change',browserSync.reload);
    watch('workspace/assets/images/**/*.{jpg,jpeg,png,gif,svg}',series(cleanImages,copyImages));
    watch('workspace/assets/fonts/**/*.{svg,eot,ttf,woff,woff2}',series(cleanfonts,copyfonts));
    watch('workspace/*.html',copyHtml);
}

//public tasks
exports.default = series(clean,parallel(css,js,copyImages,copyfonts,copyHtml),watchForChanges);
exports.build = series(clean,parallel(css,js,copyImages,copyfonts,copyHtml));
exports.imgmin = copyImages;