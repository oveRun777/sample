import Person from './test';
import callApi from './arry';
const john = new Person('John',35);

callApi();
console.log(john.getInfo());