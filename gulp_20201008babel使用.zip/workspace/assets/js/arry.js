async function callApi() {
    const USERS_API = "https://jsonplaceholder.typicode.com/users";
    const res = await window.fetch(USERS_API);
    const users = await res.json();
    console.log(users);
  }
export default callApi;