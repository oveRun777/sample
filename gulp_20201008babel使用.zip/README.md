# gulp-4-starter

Gulp 4 starter(SCSS, Babel, img , Browser Sync)

/////必要なファイル/////
workspace
.browserslistrc
gulpfile.js
package.json
package-lock.json
README.md
/////必要なファイル/////

上記を作業ディレクトリにコピーしてコマンドを立ち上げ。
npm install で開始

//命令形
npx gulp　でデベロッパー環境でのブラウザ立ち上げ、画像圧縮、ソースマップ書き出し、sassコンパイル、cssファイルまとめ、ES5対応などを行う
npx gulp build --producuts　で本番環境へのアップロードファイル作成（コメント削除、ミニファイ化等）。
npx gulp imgmin　で画像圧縮、コピーのみ行う